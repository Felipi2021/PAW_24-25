from sprawdzian import main

__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Filip Andrzejczak 4D"

if __name__ == "__main__":
    main()