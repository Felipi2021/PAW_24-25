__copyright__ = "Zespół Szkół Komunikacji"
__author__ = "Filip Andrzejczak 4D"